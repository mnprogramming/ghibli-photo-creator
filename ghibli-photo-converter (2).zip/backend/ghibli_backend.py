from fastapi import FastAPI, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import shutil
import uuid
import os

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = "uploaded_images"
RESULT_DIR = "converted_images"

os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(RESULT_DIR, exist_ok=True)

@app.post("/convert")
async def convert_image(image: UploadFile = File(...)):
    input_filename = f"{uuid.uuid4()}.png"
    input_path = os.path.join(UPLOAD_DIR, input_filename)
    with open(input_path, "wb") as buffer:
        shutil.copyfileobj(image.file, buffer)

    output_filename = f"ghibli_{input_filename}"
    output_path = os.path.join(RESULT_DIR, output_filename)
    shutil.copyfile(input_path, output_path)

    public_url = f"https://ghibli-photo-converter-backend.onrender.com/converted_images/{output_filename}"
    return JSONResponse(content={"ghibli_image_url": public_url})

from fastapi.staticfiles import StaticFiles
app.mount("/converted_images", StaticFiles(directory=RESULT_DIR), name="converted")
